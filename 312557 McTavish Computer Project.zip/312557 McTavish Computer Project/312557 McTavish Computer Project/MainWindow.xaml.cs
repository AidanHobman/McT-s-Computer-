﻿/* Aidan Hobman 
 * Feb 26, 2019
 * This is a project about building a computer un $2000 for Mr. McTavish. 
 */ 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _312557_McTavish_Computer_Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MotherboardButton_Click(object sender, RoutedEventArgs e)
        {
            Motherboard MB = new Motherboard();
            MB.ShowDialog(); 
        }

        private void CPUButton_Click(object sender, RoutedEventArgs e)
        {
            CPU CPU = new CPU();
            CPU.ShowDialog(); 
        }

        private void StorageButton_Click(object sender, RoutedEventArgs e)
        {
            Storage Srg = new Storage();
            Srg.ShowDialog(); 
        }

        private void MemoryButton_Click(object sender, RoutedEventArgs e)
        {
            Memory Mem = new Memory();
            Mem.ShowDialog(); 
        }

        private void GraphicsButton_Click(object sender, RoutedEventArgs e)
        {
            Graphics Grp = new Graphics();
            Grp.ShowDialog(); 
        }

        private void PowerButton_Click(object sender, RoutedEventArgs e)
        {
            Power Pwr = new Power();
            Pwr.ShowDialog(); 
        }

        private void DiskDriveButton_Click(object sender, RoutedEventArgs e)
        {

        }

        private void OpticalDriveButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
